#!/bin/bash

sed -e 's/pragma No_Return (Not_Implemented_Mapping);//g' -i ./asis/a4g-mapping.adb
